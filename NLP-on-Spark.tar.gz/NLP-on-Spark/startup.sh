docker run -p 8888:8888 -v $PWD/:/srv/toree/dist/toree-pip/NLP-on-Spark/ -e SPARK_OPTS="--master=local[4] --driver-memory=12g" --user=root nicoinn/apache-toree:v0.0.1
